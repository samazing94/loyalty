@extends('layouts.dashboard')
@section('section')

<div class="">
	<div class="clearfix"></div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<p> Successfully created Offer </p>				
			</div>
		</div>
	</div>
</div>
@stop